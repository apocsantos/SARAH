<?php
require __DIR__ . '/lib/bootstrap.php';
$msg = ''; $err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf'] ?? '')) $err = 'Token CSRF inválido.';
    else {
        rate_limit_simple('forgot_password', 10, 900);
        $username = trim($_POST['username'] ?? '');
        if ($username === '') $err = 'Indica o utilizador.';
        else {
            $stmt = db()->prepare("SELECT id, username FROM users WHERE username = ? AND is_active = 1");
            $stmt->execute([$username]);
            $u = $stmt->fetch();
            if ($u) {
                $tokenData = create_password_reset_token((int)$u['id']);
                send_password_reset_email((string)$u['username'], $tokenData['selector'], $tokenData['token']);
                audit_log('password_reset_requested', (string)$u['username'], (int)$u['id'], (string)$u['username']);
            }
            $msg = 'Se a conta existir, foi iniciado o processo de reset.';
        }
    }
}
?><!doctype html>
<html lang="pt"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Recuperar password</title>
<style>body{font-family:Arial;background:#0f172a;color:#e5e7eb;display:flex;min-height:100vh;align-items:center;justify-content:center;margin:0}.card{width:100%;max-width:520px;background:#111827;border:1px solid #334155;border-radius:16px;padding:24px}input,button{width:100%;padding:12px;border-radius:10px;border:1px solid #334155;box-sizing:border-box}input{background:#0b1220;color:#e5e7eb;margin:8px 0 14px}button{background:#38bdf8;color:#082f49;font-weight:700;cursor:pointer}.msg{background:#14532d;padding:10px;border-radius:10px;margin-bottom:12px}.err{background:#7f1d1d;padding:10px;border-radius:10px;margin-bottom:12px}a{color:#93c5fd}</style>
</head><body><div class="card"><h2>Recuperar password</h2><?php if($msg): ?><div class="msg"><?= h($msg) ?></div><?php endif; ?><?php if($err): ?><div class="err"><?= h($err) ?></div><?php endif; ?><form method="post"><input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>"><input name="username" placeholder="utilizador" required><button type="submit">Enviar link de reset</button></form><p><a href="index.php">Voltar ao login</a></p></div></body></html>
