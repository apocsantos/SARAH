<?php
require __DIR__ . '/lib/bootstrap.php';
require_role(['superadmin','editor']);
$msg=''; $err='';
function extract_zip_to_storage_hardened(string $tmpFile): array {
    $zip=new ZipArchive();
    if($zip->open($tmpFile)!==true) return ['ok'=>false,'message'=>'Não foi possível abrir o ZIP.'];
    for($i=0;$i<$zip->numFiles;$i++){
        $name=$zip->getNameIndex($i); if($name===false) continue;
        $name=normalize_relative_path($name); if($name==='') continue;
        $contents=$zip->getFromIndex($i); if($contents===false) continue;
        if(strtolower(basename($name))==='seed.json' || strtolower(basename($name))==='sarah_dados.json'){
            $decoded=json_decode($contents,true);
            if(is_array($decoded)){ $decoded=seed_payload_or_fail($decoded); file_put_contents(seed_path(), json_encode($decoded, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)); }
            continue;
        }
        if(str_ends_with(strtolower($name), '.svg')) {
            $contents=require_svg_or_fail((string)$contents);
            if (!str_starts_with($name, 'icons/')) {
                $name = 'icons/importados/' . basename($name);
            }
        }
        $target=safe_storage_path($name); $dir=dirname($target); if(!is_dir($dir)) mkdir($dir,0775,true); file_put_contents($target,$contents);
    }
    $zip->close(); return ['ok'=>true,'message'=>'ZIP importado com sucesso.'];
}
if($_SERVER['REQUEST_METHOD']==='POST'){
    if(!csrf_check($_POST['csrf'] ?? '')) $err='Token CSRF inválido.';
    else { rate_limit_simple('upload_zip', 20, 300);
        if(empty($_FILES['zip_file']['tmp_name'])) $err='Falta ZIP.';
        else { $r=extract_zip_to_storage_hardened($_FILES['zip_file']['tmp_name']); if($r['ok']){ $msg=$r['message']; $u=current_user(); audit_log('upload_zip','', (int)$u['id'], (string)$u['username']); } else $err=$r['message']; }
    }
}
?><!doctype html>
<html lang="pt"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Upload SARAH</title>
<style>body{font-family:Arial;background:#0f172a;color:#e5e7eb;margin:0}.wrap{max-width:1000px;margin:0 auto;padding:20px}.card{background:#111827;border:1px solid #334155;border-radius:16px;padding:18px;margin-bottom:18px}input,button{padding:12px;border-radius:10px;border:1px solid #334155;box-sizing:border-box}input[type=file]{width:100%;background:#0b1220;color:#e5e7eb}button{background:#38bdf8;color:#082f49;font-weight:700;cursor:pointer}.msg{background:#14532d;padding:10px;border-radius:10px;margin-bottom:12px}.err{background:#7f1d1d;padding:10px;border-radius:10px;margin-bottom:12px}a{color:#93c5fd}</style>
</head><body><div class="wrap"><p><a href="dashboard.php">← Dashboard</a></p><div class="card"><?php if($msg): ?><div class="msg"><?= h($msg) ?></div><?php endif; ?><?php if($err): ?><div class="err"><?= h($err) ?></div><?php endif; ?><h3>Importar ZIP do editor</h3><form method="post" enctype="multipart/form-data"><input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>"><input type="file" name="zip_file" accept=".zip,application/zip" required><p><button type="submit">Importar ZIP</button></p></form></div></div></body></html>
