<?php
return [
    'db_host' => '127.0.0.1',
    'db_port' => 3306,
    'db_name' => 'ebaveromar_sarah',
    'db_user' => 'ebaveromar_SaintPeter',
    'db_pass' => 'Cod3Breaker$',
    'db_charset' => 'utf8mb4',

    'issuer' => 'SARAH',
    'session_name' => 'SARAHADMINSESSID',
    'session_secure' => false,
    'session_samesite' => 'Strict',
    'session_idle_timeout' => 1800,
    'password_min_length' => 12,

    'storage_root' => __DIR__ . '/storage',
    'seed_filename' => 'seed.json',

    'local_captcha_enabled' => true,

    // opcionais para reset por email
    'mail_from' => 'sarah@aeaveromar.pt',
    'mail_reset_base_url' => 'https://sarah.aeaveromar.pt',
];
