<?php
require __DIR__ . '/lib/bootstrap.php';
if (is_authenticated()) { header('Location: dashboard.php'); exit; }

$error = '';
$step = $_SESSION['auth_step'] ?? 'login';
$username = trim($_POST['username'] ?? ($_SESSION['login_username'] ?? ''));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf'] ?? '')) {
        $error = 'Token CSRF inválido.';
    } elseif ($step === 'login') {
        rate_limit_simple('login_form', 40, 300);
        if ($username === '') {
            $error = 'Utilizador em falta.';
        } elseif (is_ip_locked_db() || is_user_locked_db($username)) {
            $error = 'Acesso temporariamente bloqueado devido a tentativas falhadas.';
        } else {
            captcha_regenerate_if_missing();
            $captchaOk = captcha_check($_POST['captcha'] ?? '');
            $s = db()->prepare("SELECT * FROM users WHERE username = ? AND is_active = 1");
            $s->execute([$username]);
            $u = $s->fetch();
            $passwordOk = $u && password_verify($_POST['password'] ?? '', $u['password_hash']);

            if ($captchaOk && $passwordOk) {
                $_SESSION['login_user_id'] = (int)$u['id'];
                $_SESSION['login_username'] = (string)$u['username'];
                $_SESSION['auth_step'] = 'totp';
                log_login_attempt_db($username, true, 'password');
                $step = 'totp';
            } else {
                log_login_attempt_db($username, false, 'password');
                $error = 'Credenciais inválidas.';
            }
        }
    } else {
        $uid = (int)($_SESSION['login_user_id'] ?? 0);
        $s = db()->prepare("SELECT * FROM users WHERE id = ? AND is_active = 1");
        $s->execute([$uid]);
        $u = $s->fetch();
        if ($u && verify_totp((string)$u['totp_secret'], preg_replace('/\D+/','', $_POST['totp'] ?? ''), 1)) {
            $_SESSION['authenticated'] = true;
            $_SESSION['user_id'] = (int)$u['id'];
            $_SESSION['auth_step'] = 'done';
            $_SESSION['last_activity_at'] = time();
            session_regenerate_id(true);
            db()->prepare("UPDATE users SET last_login_at = NOW() WHERE id = ?")->execute([(int)$u['id']]);
            log_login_attempt_db((string)$u['username'], true, 'totp');
            audit_log('login_ok', '', (int)$u['id'], (string)$u['username']);
            header('Location: dashboard.php');
            exit;
        } else {
            log_login_attempt_db((string)($_SESSION['login_username'] ?? $username), false, 'totp');
            $error = 'Código 2FA inválido.';
        }
    }
}
captcha_regenerate_if_missing();
?><!doctype html>
<html lang="pt"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Login SARAH</title>
<style>body{font-family:Arial;background:#0f172a;color:#e5e7eb;display:flex;min-height:100vh;align-items:center;justify-content:center;margin:0}.card{width:100%;max-width:460px;background:#111827;border:1px solid #334155;border-radius:16px;padding:24px}input,button{width:100%;padding:12px;border-radius:10px;border:1px solid #334155;box-sizing:border-box}input{background:#0b1220;color:#e5e7eb;margin:8px 0 14px}button{background:#38bdf8;color:#082f49;font-weight:700;cursor:pointer}.err{background:#7f1d1d;padding:10px;border-radius:10px;margin-bottom:12px}a{color:#93c5fd}</style>
</head><body><div class="card"><h2>SARAH Admin</h2><?php if(!empty($_GET['expired'])): ?><div class="err">Sessão expirada por inatividade.</div><?php endif; ?><?php if($error): ?><div class="err"><?= h($error) ?></div><?php endif; ?><?php if($step === 'login'): ?><form method="post"><input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>"><input name="username" placeholder="utilizador" value="<?= h($username) ?>" required><input type="password" name="password" placeholder="password" required><label>Captcha: <?= (int)$_SESSION['captcha_a'] ?> + <?= (int)$_SESSION['captcha_b'] ?> ?</label><input name="captcha" required><button type="submit">Entrar</button></form><p><a href="forgot_password.php">Esqueci-me da password</a></p><?php else: ?><form method="post"><input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>"><input name="totp" placeholder="código 2FA" required><button type="submit">Validar 2FA</button></form><?php endif; ?></div></body></html>
