<?php
$configFile = __DIR__ . '/../config.php';
if (!file_exists($configFile)) die('Falta config.php. Copia config.sample.php para config.php.');
define('CONFIG', require $configFile);

session_name(CONFIG['session_name'] ?? 'SARAHSESSID');
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => !empty(CONFIG['session_secure']),
    'httponly' => true,
    'samesite' => CONFIG['session_samesite'] ?? 'Strict',
]);
session_start();

require __DIR__ . '/db.php';
require __DIR__ . '/helpers.php';
require __DIR__ . '/totp.php';
require __DIR__ . '/security_extra.php';

if (!is_dir(CONFIG['storage_root'])) mkdir(CONFIG['storage_root'], 0775, true);

security_headers();
require_https_or_local();
rate_limit_simple('global', 240, 60);
enforce_session_idle_timeout();

if (!empty($_SESSION['authenticated']) && empty($_SESSION['session_rotated_at'])) {
    session_regenerate_id(true);
    $_SESSION['session_rotated_at'] = time();
} elseif (!empty($_SESSION['authenticated']) && (time() - (int)($_SESSION['session_rotated_at'] ?? 0) > 900)) {
    session_regenerate_id(true);
    $_SESSION['session_rotated_at'] = time();
}
