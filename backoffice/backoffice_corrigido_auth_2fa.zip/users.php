<?php
require __DIR__ . '/lib/bootstrap.php';
require_role(['superadmin']);
$msg=''; $err='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    if(!csrf_check($_POST['csrf'] ?? '')) $err='Token CSRF inválido.';
    else {
        $mode=$_POST['mode'] ?? '';
        if($mode==='create'){
            $username=trim($_POST['username'] ?? '');
            $password=$_POST['password'] ?? '';
            $totp=trim($_POST['totp_secret'] ?? '');
            $role=$_POST['role'] ?? 'viewer';
            if($username===''||$password===''||$totp==='') $err='Preenche tudo.';
            elseif(!password_is_strong_enough($password)) $err='Password demasiado fraca.';
            else {
                $s=db()->prepare("INSERT INTO users (username, password_hash, totp_secret, role, is_active, created_at) VALUES (?,?,?,?,1,NOW())");
                $s->execute([$username, password_hash($password, PASSWORD_DEFAULT), $totp, $role]);
                $u=current_user(); audit_log('user_create',$username . ' / ' . $role, (int)$u['id'], (string)$u['username']);
                $msg='Utilizador criado.';
            }
        } elseif($mode==='toggle'){
            $id=(int)($_POST['id'] ?? 0);
            db()->prepare("UPDATE users SET is_active = IF(is_active=1,0,1) WHERE id=?")->execute([$id]);
            $msg='Estado alterado.';
        } elseif($mode==='reset_password'){
            $id=(int)($_POST['id'] ?? 0);
            $password=$_POST['new_password'] ?? '';
            if(!password_is_strong_enough($password)) $err='Password demasiado fraca.';
            else {
                db()->prepare("UPDATE users SET password_hash=? WHERE id=?")->execute([password_hash($password, PASSWORD_DEFAULT), $id]);
                $msg='Password redefinida.';
            }
        }
    }
}
$users=db()->query("SELECT id, username, role, is_active, created_at, last_login_at FROM users ORDER BY id ASC")->fetchAll();
?><!doctype html>
<html lang="pt"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Utilizadores</title>
<style>body{font-family:Arial;background:#0f172a;color:#e5e7eb;margin:0}.wrap{max-width:1200px;margin:0 auto;padding:20px}.card{background:#111827;border:1px solid #334155;border-radius:16px;padding:18px;margin-bottom:18px}input,select,button{padding:10px;border-radius:10px;border:1px solid #334155;box-sizing:border-box;background:#0b1220;color:#e5e7eb}button{background:#38bdf8;color:#082f49;font-weight:700;cursor:pointer}a{color:#93c5fd}table{width:100%;border-collapse:collapse}th,td{border-bottom:1px solid #334155;padding:8px;text-align:left;font-size:13px}.msg{background:#14532d;padding:10px;border-radius:10px;margin-bottom:12px}.err{background:#7f1d1d;padding:10px;border-radius:10px;margin-bottom:12px}.row{display:grid;grid-template-columns:1fr 1fr 1fr 1fr auto;gap:10px}</style>
</head><body><div class="wrap"><p><a href="dashboard.php">← Dashboard</a></p><div class="card"><?php if($msg): ?><div class="msg"><?= h($msg) ?></div><?php endif; ?><?php if($err): ?><div class="err"><?= h($err) ?></div><?php endif; ?><h3>Criar utilizador</h3><form method="post"><input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>"><input type="hidden" name="mode" value="create"><div class="row"><input name="username" placeholder="username" required><input type="password" name="password" placeholder="password" required><input name="totp_secret" placeholder="segredo TOTP Base32" required><select name="role"><option>viewer</option><option>editor</option><option>superadmin</option></select><button type="submit">Criar</button></div></form></div><div class="card"><h3>Utilizadores</h3><table><thead><tr><th>ID</th><th>Username</th><th>Role</th><th>Ativo</th><th>Criado</th><th>Último login</th><th>Ações</th></tr></thead><tbody><?php foreach($users as $usr): ?><tr><td><?= (int)$usr['id'] ?></td><td><?= h($usr['username']) ?></td><td><?= h($usr['role']) ?></td><td><?= !empty($usr['is_active']) ? 'Sim' : 'Não' ?></td><td><?= h((string)$usr['created_at']) ?></td><td><?= h((string)$usr['last_login_at']) ?></td><td><form method="post" style="display:inline"><input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>"><input type="hidden" name="mode" value="toggle"><input type="hidden" name="id" value="<?= (int)$usr['id'] ?>"><button type="submit">Ativar/Desativar</button></form><form method="post" style="display:inline-flex;gap:8px;align-items:center;margin-left:8px"><input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>"><input type="hidden" name="mode" value="reset_password"><input type="hidden" name="id" value="<?= (int)$usr['id'] ?>"><input type="text" name="new_password" placeholder="nova password"><button type="submit">Reset</button></form></td></tr><?php endforeach; ?></tbody></table></div></div></body></html>
