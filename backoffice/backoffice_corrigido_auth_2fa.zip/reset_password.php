<?php
require __DIR__ . '/lib/bootstrap.php';
$msg = ''; $err = '';
$selector = trim($_GET['selector'] ?? $_POST['selector'] ?? '');
$token = trim($_GET['token'] ?? $_POST['token'] ?? '');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf'] ?? '')) $err = 'Token CSRF inválido.';
    else {
        rate_limit_simple('reset_password', 10, 900);
        $password = $_POST['password'] ?? '';
        $password2 = $_POST['password2'] ?? '';
        if ($password !== $password2) $err = 'As passwords não coincidem.';
        elseif (!password_is_strong_enough($password)) $err = 'Password demasiado fraca.';
        else {
            $row = find_valid_reset_token($selector);
            if (!$row || !password_verify($token, (string)$row['token_hash'])) {
                $err = 'Token inválido ou expirado.';
            } else {
                db()->prepare("UPDATE users SET password_hash = ? WHERE id = ?")->execute([password_hash($password, PASSWORD_DEFAULT), (int)$row['user_id']]);
                mark_reset_token_used((int)$row['id']);
                audit_log('password_reset_completed', 'user_id=' . (int)$row['user_id'], (int)$row['user_id'], null);
                $msg = 'Password redefinida com sucesso. Já podes entrar.';
            }
        }
    }
}
?><!doctype html>
<html lang="pt"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Reset de password</title>
<style>body{font-family:Arial;background:#0f172a;color:#e5e7eb;display:flex;min-height:100vh;align-items:center;justify-content:center;margin:0}.card{width:100%;max-width:520px;background:#111827;border:1px solid #334155;border-radius:16px;padding:24px}input,button{width:100%;padding:12px;border-radius:10px;border:1px solid #334155;box-sizing:border-box}input{background:#0b1220;color:#e5e7eb;margin:8px 0 14px}button{background:#38bdf8;color:#082f49;font-weight:700;cursor:pointer}.msg{background:#14532d;padding:10px;border-radius:10px;margin-bottom:12px}.err{background:#7f1d1d;padding:10px;border-radius:10px;margin-bottom:12px}a{color:#93c5fd}</style>
</head><body><div class="card"><h2>Reset de password</h2><?php if($msg): ?><div class="msg"><?= h($msg) ?></div><?php endif; ?><?php if($err): ?><div class="err"><?= h($err) ?></div><?php endif; ?><form method="post"><input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>"><input type="hidden" name="selector" value="<?= h($selector) ?>"><input type="hidden" name="token" value="<?= h($token) ?>"><input type="password" name="password" placeholder="nova password" required><input type="password" name="password2" placeholder="repetir password" required><button type="submit">Redefinir password</button></form><p><a href="index.php">Voltar ao login</a></p></div></body></html>
