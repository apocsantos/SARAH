<?php
require __DIR__ . '/../lib/bootstrap.php';
require_role(['superadmin','editor','viewer']);
rate_limit_simple('api_library', 120, 300);
$items = [];
$root = storage_root();
$iconsRoot = $root . DIRECTORY_SEPARATOR . 'icons';
if (is_dir($iconsRoot)) {
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($iconsRoot, FilesystemIterator::SKIP_DOTS));
    foreach ($it as $file) {
        if (!$file->isFile()) continue;
        if (strtolower($file->getExtension()) !== 'svg') continue;
        if ($file->getSize() > 1024 * 1024) continue;
        $full = $file->getPathname();
        $rel = str_replace('\\', '/', substr($full, strlen($root) + 1));
        $content = file_get_contents($full);
        if ($content === false) continue;
        $parts = explode('/', $rel);
        $category = (count($parts) >= 2 && $parts[0] === 'icons') ? $parts[1] : '';
        $items[] = [
            'path' => $rel,
            'fileName' => basename($rel),
            'name' => preg_replace('/\.svg$/i', '', basename($rel)),
            'category' => $category,
            'tags' => [],
            'content' => $content,
        ];
    }
}
$u=current_user(); audit_log('api_library_manifest','library', (int)$u['id'], (string)$u['username']);
header('Content-Type: application/json; charset=utf-8');
echo json_encode(['items'=>$items], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
