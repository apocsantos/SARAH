<?php
require __DIR__ . '/../lib/bootstrap.php';
require_role(['superadmin','editor','viewer']);
rate_limit_simple('api_seed', 120, 300);
$p = seed_path();
$u=current_user(); audit_log('api_seed_get','seed', (int)$u['id'], (string)$u['username']);
header('Content-Type: application/json; charset=utf-8');
if (!file_exists($p)) {
    echo json_encode(['versao'=>1,'idioma'=>'pt-PT','voz'=>['lang'=>'pt-PT','rate'=>1.0,'pitch'=>1.0],'categorias'=>[],'itens'=>[]], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    exit;
}
readfile($p);
