<?php
require __DIR__ . '/lib/bootstrap.php';
ensure_auth();
$u = current_user();
$missing = seed_missing_icons();
$files = list_storage_files(storage_root());
$audit = recent_audit_entries(20);
?>
<!doctype html>
<html lang="pt">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Dashboard SARAH</title>
<style>
body{font-family:Arial;background:#0f172a;color:#e5e7eb;margin:0}
.wrap{max-width:1200px;margin:0 auto;padding:20px}
.card{background:#111827;border:1px solid #334155;border-radius:16px;padding:18px;margin-bottom:18px}
a{color:#93c5fd}
table{width:100%;border-collapse:collapse}
th,td{border-bottom:1px solid #334155;padding:8px;text-align:left;font-size:13px}
.actions{display:flex;flex-wrap:wrap;gap:10px;margin-top:10px}
.btn{display:inline-block;padding:10px 14px;border:1px solid #334155;border-radius:10px;background:#0b1220;text-decoration:none}
.btn.primary{background:#38bdf8;color:#082f49;border-color:#0ea5e9;font-weight:700}
</style>
</head>
<body>
<div class="wrap">
  <h2>SARAH Dashboard</h2>

  <p>
    <?= h($u['username']) ?> (<?= h($u['role']) ?>)
    · <a href="editor.php">Editor</a>
    · <a href="upload.php">Upload</a>
    · <a href="library_browser.php">Biblioteca</a>
    · <a href="api/seed_api.php">Seed API</a>
    <?php if($u['role']==='superadmin'): ?> · <a href="users.php">Utilizadores</a><?php endif; ?>
    · <a href="setup.php">2FA</a>
    · <a href="logout.php">Sair</a>
  </p>

  <div class="card">
    <h3>Acesso rápido</h3>
    <div class="actions">
      <a class="btn primary" href="editor.php">Abrir Editor</a>
      <a class="btn" href="library_browser.php">Navegar biblioteca</a>
      <a class="btn" href="upload.php">Importar ZIP</a>
      <a class="btn" href="api/seed_api.php">Ver seed.json</a>
      <?php if($u['role']==='superadmin'): ?><a class="btn" href="users.php">Gerir utilizadores</a><?php endif; ?>
    </div>
  </div>

  <div class="card">
    <p>Ficheiros publicados: <?= count($files) ?></p>
    <p>Ícones em falta: <?= count($missing) ?></p>
    <p>seed.json: <code><?= h(seed_path()) ?></code></p>
  </div>

  <div class="card">
    <h3>Auditoria recente</h3>
    <table>
      <thead><tr><th>Quando</th><th>Ação</th><th>Utilizador</th></tr></thead>
      <tbody>
      <?php foreach($audit as $a): ?>
        <tr>
          <td><?= h((string)$a['created_at']) ?></td>
          <td><?= h((string)$a['action']) ?></td>
          <td><?= h((string)$a['username']) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
</body>
</html>
