<?php
require __DIR__ . '/lib/bootstrap.php';
$u=current_user(); if($u) audit_log('logout','', (int)$u['id'], (string)$u['username']);
logout_now();
header('Location: index.php');
exit;
