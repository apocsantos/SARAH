<?php require __DIR__ . '/lib/common.php'; ?>
<!doctype html>
<html lang="pt">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>SARAH - Navegador de pictogramas</title>
<style>
:root{--bg:#0f172a;--panel:#111827;--panel2:#0b1220;--line:#334155;--text:#e5e7eb;--muted:#94a3b8;--accent:#38bdf8}
*{box-sizing:border-box}
body{margin:0;font-family:Arial,Helvetica,sans-serif;background:var(--bg);color:var(--text)}
.wrap{max-width:1500px;margin:0 auto;padding:20px}
.panel{background:var(--panel);border:1px solid var(--line);border-radius:18px;padding:16px;margin-bottom:16px}
.toolbar{display:flex;gap:10px;flex-wrap:wrap;align-items:center}
button,input{font:inherit;border-radius:10px;border:1px solid var(--line)}
button{padding:10px 14px;background:#1f2937;color:var(--text);cursor:pointer}
button.primary{background:var(--accent);color:#082f49;font-weight:700}
input{padding:10px 12px;background:var(--panel2);color:var(--text);min-width:320px}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:12px}
.card{background:var(--panel2);border:1px solid var(--line);border-radius:16px;padding:12px;display:flex;flex-direction:column;gap:8px;min-height:170px}
.card.selected{outline:3px solid var(--accent)}
.folder{justify-content:center;align-items:center;text-align:center;cursor:pointer}
.folderIcon{font-size:52px}
.thumb{height:112px;border:1px solid var(--line);border-radius:12px;background:#0f172a;display:flex;align-items:center;justify-content:center;overflow:hidden}
.thumb svg{max-width:96px;max-height:96px}
.name{font-weight:700;font-size:13px;word-break:break-word}
.path{font-size:12px;color:var(--muted);word-break:break-all}
.status{color:#93c5fd;font-size:13px}
.breadcrumb{font-size:14px;color:var(--muted);word-break:break-all}
.preview{display:grid;grid-template-columns:130px 1fr;gap:16px;align-items:start}
.previewBox{width:120px;height:120px;border:1px solid var(--line);border-radius:18px;display:flex;align-items:center;justify-content:center;background:#0f172a}
.previewBox svg{max-width:100px;max-height:100px}
@media(max-width:700px){.preview{grid-template-columns:1fr}input{min-width:0;width:100%}}
</style>
</head>
<body>
<div class="wrap">
  <h1>SARAH - Navegador de pictogramas</h1>
  <p class="status">Navega pelas pastas dentro de <code>storage/icons/</code> e copia o caminho para usar no seed.json.</p>

  <div class="panel">
    <div class="toolbar">
      <button id="rootBtn">Raiz icons/</button>
      <button id="backBtn">Voltar</button>
      <input id="search" placeholder="Pesquisar nesta pasta...">
      <button class="primary" id="copyBtn">Copiar caminho selecionado</button>
    </div>
    <p class="breadcrumb" id="breadcrumb">icons</p>
    <p class="status" id="status">Pronto.</p>
  </div>

  <div class="panel preview" id="previewPanel" style="display:none">
    <div class="previewBox" id="previewIcon"></div>
    <div>
      <h2 id="previewName" style="margin-top:0"></h2>
      <p class="path" id="previewPath"></p>
    </div>
  </div>

  <div class="panel">
    <h2>Pastas</h2>
    <div class="grid" id="foldersGrid"></div>
  </div>

  <div class="panel">
    <h2>Ficheiros SVG</h2>
    <div class="grid" id="filesGrid"></div>
  </div>
</div>

<script>
const state = { current: 'icons', parent: null, dirs: [], files: [], selected: null };
const $ = id => document.getElementById(id);
const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function setStatus(msg){ $('status').textContent = msg; }

async function loadDir(dir='icons'){
  try{
    setStatus('A carregar...');
    const res = await fetch('api/library_tree.php?dir=' + encodeURIComponent(dir));
    const data = await res.json();
    if(!res.ok || data.ok === false) throw new Error(data.error || 'Erro');
    state.current = data.current;
    state.parent = data.parent;
    state.dirs = data.dirs || [];
    state.files = data.files || [];
    state.selected = null;
    $('breadcrumb').textContent = state.current;
    render();
    setStatus(`${state.dirs.length} pasta(s), ${state.files.length} SVG.`);
  }catch(e){
    setStatus('Erro ao carregar diretoria: ' + e.message);
  }
}

function filteredFiles(){
  const q = $('search').value.trim().toLowerCase();
  if(!q) return state.files;
  return state.files.filter(f => (f.name + ' ' + f.path).toLowerCase().includes(q));
}
function filteredDirs(){
  const q = $('search').value.trim().toLowerCase();
  if(!q) return state.dirs;
  return state.dirs.filter(d => (d.name + ' ' + d.path).toLowerCase().includes(q));
}
function render(){ renderFolders(); renderFiles(); renderPreview(); }

function renderFolders(){
  const grid = $('foldersGrid');
  grid.innerHTML = '';
  const dirs = filteredDirs();
  if(dirs.length === 0){
    grid.innerHTML = '<p class="status">Sem subpastas.</p>';
    return;
  }
  dirs.forEach(d => {
    const el = document.createElement('button');
    el.className = 'card folder';
    el.innerHTML = `<div class="folderIcon">📁</div><div class="name">${esc(d.name)}</div><div class="path">${esc(d.path)}</div>`;
    el.addEventListener('click', () => loadDir(d.path));
    grid.appendChild(el);
  });
}

function renderFiles(){
  const grid = $('filesGrid');
  grid.innerHTML = '';
  const files = filteredFiles();
  if(files.length === 0){
    grid.innerHTML = '<p class="status">Sem SVG nesta pasta.</p>';
    return;
  }
  files.forEach(f => {
    const el = document.createElement('button');
    el.className = 'card' + (state.selected && state.selected.path === f.path ? ' selected' : '');
    el.innerHTML = `<div class="thumb">${f.content}</div><div class="name">${esc(f.name)}</div><div class="path">${esc(f.path)}</div>`;
    el.addEventListener('click', () => {
      state.selected = f;
      renderFiles();
      renderPreview();
      setStatus('Selecionado: ' + f.path);
    });
    grid.appendChild(el);
  });
}

function renderPreview(){
  const p = $('previewPanel');
  if(!state.selected){ p.style.display = 'none'; return; }
  p.style.display = '';
  $('previewIcon').innerHTML = state.selected.content;
  $('previewName').textContent = state.selected.name;
  $('previewPath').textContent = state.selected.path;
}

async function copySelected(){
  if(!state.selected){ setStatus('Seleciona primeiro um símbolo.'); return; }
  try{
    await navigator.clipboard.writeText(state.selected.path);
    setStatus('Caminho copiado: ' + state.selected.path);
  }catch{
    setStatus('Não foi possível copiar. Caminho: ' + state.selected.path);
  }
}

$('rootBtn').addEventListener('click', () => loadDir('icons'));
$('backBtn').addEventListener('click', () => { if(state.parent) loadDir(state.parent); });
$('copyBtn').addEventListener('click', copySelected);
$('search').addEventListener('input', render);
loadDir('icons');
</script>
</body>
</html>
