<?php require __DIR__ . '/lib/bootstrap.php'; require_role(['superadmin','editor','viewer']); ?>
<!doctype html>
<html lang="pt">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>SARAH - ACC Editor Integrado</title>
<style>
:root{--bg:#0f172a;--panel:#111827;--panel2:#1f2937;--text:#e5e7eb;--muted:#94a3b8;--accent:#38bdf8;--line:#334155;--good:#166534;--warn:#92400e;--bad:#991b1b}
*{box-sizing:border-box}body{margin:0;font-family:Segoe UI,Arial,sans-serif;background:#0f172a;color:var(--text)}
.wrap{max-width:1680px;margin:0 auto;padding:18px}.grid{display:grid;grid-template-columns:430px 1fr;gap:18px;align-items:start}.subgrid{display:grid;grid-template-columns:1fr;gap:18px}.panel{background:#111827;border:1px solid #334155;border-radius:16px;padding:16px}
.stack{display:flex;flex-direction:column;gap:12px}.row{display:grid;grid-template-columns:1fr 1fr;gap:10px}.kpi{display:grid;grid-template-columns:repeat(5,1fr);gap:10px}.kpi .box{background:#0b1220;border:1px solid #334155;border-radius:12px;padding:10px}.kpi .n{font-size:24px;font-weight:700}
label{display:block;font-size:12px;color:var(--muted);margin:0 0 6px}input,textarea,select,button{width:100%;font:inherit;border:1px solid #334155;border-radius:10px}input,textarea,select{background:#0b1220;color:var(--text);padding:10px 12px}textarea{min-height:90px;resize:vertical}
button{cursor:pointer;padding:10px 14px;background:var(--panel2);color:var(--text)}button.primary{background:var(--accent);color:#082f49;border-color:#0ea5e9;font-weight:700}button.good{background:var(--good)}button.warn{background:var(--warn)}button.bad{background:var(--bad)}
.toolbar{display:flex;flex-wrap:wrap;gap:8px}.tabs{display:flex;gap:8px;flex-wrap:wrap}.tabBtn{width:auto}.list{display:flex;flex-direction:column;gap:10px;max-height:320px;overflow:auto;padding-right:4px}.entry{border:1px solid #334155;border-radius:14px;padding:12px;background:#0b1220}.entry.active{outline:2px solid var(--accent)}.entryTop{display:flex;justify-content:space-between;gap:10px;align-items:center}.title{font-weight:700}.mini{font-size:12px;color:var(--muted)}
.assetGrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(165px,1fr));gap:12px;max-height:620px;overflow:auto;padding-right:4px}.assetCard{border:1px solid #334155;border-radius:16px;padding:10px;background:#0b1220;display:flex;flex-direction:column;gap:8px}.assetCard.selected{outline:2px solid var(--accent)}.assetThumb{height:120px;border:1px solid #334155;border-radius:12px;background:#0f172a;display:flex;align-items:center;justify-content:center;overflow:hidden}.assetThumb svg{max-width:104px;max-height:104px}
.assetName{font-weight:700;font-size:13px;line-height:1.3;word-break:break-word}.assetMeta{font-size:12px;color:var(--muted);line-height:1.3}.searchRow{display:grid;grid-template-columns:1fr 190px 170px;gap:10px}.previewCard{display:flex;gap:16px;align-items:flex-start;border:1px solid #334155;border-radius:18px;padding:18px;background:#0b1220}.iconBox{width:96px;height:96px;border-radius:18px;background:#0f172a;border:1px solid #334155;display:flex;align-items:center;justify-content:center;overflow:hidden;font-size:36px;flex:none}.iconBox svg{max-width:84px;max-height:84px}.codeBox{min-height:300px;background:#020617;color:#d1fae5;border:1px solid #334155;padding:14px;border-radius:16px;font-family:Consolas,monospace;font-size:13px;line-height:1.5;white-space:pre;overflow:auto}.status{font-size:12px;color:#93c5fd}.top a{color:#93c5fd}
@media (max-width:1150px){.grid{grid-template-columns:1fr}.searchRow{grid-template-columns:1fr}.kpi{grid-template-columns:1fr 1fr}}
</style>
</head>
<body>
<div class="wrap">
  <div class="top"><p><a href="dashboard.php">← Dashboard</a></p></div>
  <h1 style="margin:0 0 8px;font-size:28px">SARAH - ACC Editor Integrado</h1>
  <p style="margin:0 0 18px;color:#94a3b8">Biblioteca central de pictogramas, edição do seed.json e publicação direta no servidor num só sítio.</p>

  <div class="grid">
    <div class="panel">
      <div class="stack">
        <div class="row">
          <div><label>Versão</label><input id="versao" type="number" value="1" /></div>
          <div><label>Idioma</label><input id="idioma" value="pt-PT" /></div>
        </div>
        <div class="row">
          <div><label>Voz: lang</label><input id="vozLang" value="pt-PT" /></div>
          <div><label>Voz: rate</label><input id="vozRate" type="number" step="0.1" value="1.0" /></div>
        </div>
        <div><label>Voz: pitch</label><input id="vozPitch" type="number" step="0.1" value="1.0" /></div>

        <div class="toolbar">
          <button class="good" id="loadServerLibraryBtn">Carregar biblioteca do servidor</button>
          <button class="good" id="loadServerSeedBtn">Carregar seed.json do servidor</button>
          <button class="primary" id="publishServerBtn">Publicar no servidor</button>
        </div>

        <div class="tabs">
          <button class="tabBtn primary" id="tabCategoria">Editar categoria</button>
          <button class="tabBtn" id="tabItem">Editar item</button>
        </div>

        <div id="categoriaForm">
          <div class="row">
            <div><label>ID da categoria</label><input id="catId" placeholder="comida" /></div>
            <div><label>Emoji</label><input id="catEmoji" placeholder="🍽️" /></div>
          </div>
          <div><label>Nome da categoria</label><input id="catNome" placeholder="Comida" /></div>
          <div class="toolbar">
            <button class="primary" id="saveCategoria">Guardar categoria</button>
            <button id="clearCategoria">Limpar</button>
            <button class="warn" id="dupCategoria">Duplicar</button>
            <button class="bad" id="delCategoria">Eliminar</button>
          </div>
        </div>

        <div id="itemForm" style="display:none">
          <div class="row">
            <div><label>ID do item</label><input id="itemId" placeholder="agua" /></div>
            <div><label>Categoria</label><select id="itemCategoria"></select></div>
          </div>
          <div><label>Texto</label><textarea id="itemTexto" placeholder="Quero água."></textarea></div>
          <div><label>Caminho do ícone</label><input id="itemIcone" placeholder="icons/bebidas/agua.svg" /></div>
          <div class="row">
            <div><label>Pictograma selecionado</label><input id="selectedAssetPath" readonly placeholder="Nenhum pictograma selecionado" /></div>
            <div><label>&nbsp;</label><button id="applyAssetToItem">Aplicar pictograma ao item</button></div>
          </div>
          <div class="toolbar">
            <button class="primary" id="saveItem">Guardar item</button>
            <button id="clearItem">Limpar</button>
            <button class="warn" id="dupItem">Duplicar</button>
            <button class="bad" id="delItem">Eliminar</button>
          </div>
        </div>

        <div class="status" id="status">Pronto.</div>
      </div>
    </div>

    <div class="subgrid">
      <div class="panel">
        <div class="kpi">
          <div class="box"><div class="mini">Categorias</div><div class="n" id="kpiCategorias">0</div></div>
          <div class="box"><div class="mini">Itens</div><div class="n" id="kpiItens">0</div></div>
          <div class="box"><div class="mini">Pictogramas</div><div class="n" id="kpiAssets">0</div></div>
          <div class="box"><div class="mini">Em uso</div><div class="n" id="kpiUsed">0</div></div>
          <div class="box"><div class="mini">Em falta</div><div class="n" id="kpiMissing">0</div></div>
        </div>
      </div>

      <div class="panel">
        <h3 style="margin-top:0">Categorias</h3>
        <div class="list" id="listaCategorias"></div>
      </div>

      <div class="panel">
        <h3 style="margin-top:0">Itens</h3>
        <div class="searchRow">
          <input id="itemSearch" placeholder="Procurar item..." />
          <select id="itemFilterCategoria"><option value="">Todas as categorias</option></select>
          <select id="itemMissingIconFilter"><option value="">Todos</option><option value="missing">Só com ícone em falta</option><option value="ok">Só com ícone disponível</option></select>
        </div>
        <div style="height:10px"></div>
        <div class="list" id="listaItens"></div>
      </div>

      <div class="panel">
        <h3 style="margin-top:0">Biblioteca visual de pictogramas</h3>
        <div class="searchRow">
          <input id="assetSearch" placeholder="Pesquisar pictograma..." />
          <select id="assetFilterCategoria"><option value="">Todas as categorias</option></select>
          <select id="assetUsageFilter"><option value="">Todos</option><option value="used">Só usados</option><option value="unused">Só não usados</option></select>
        </div>
        <div style="height:10px"></div>
        <div class="assetGrid" id="assetGrid"></div>
      </div>

      <div class="panel">
        <h3 style="margin-top:0">Pré-visualização</h3>
        <div class="previewCard">
          <div class="iconBox" id="previewIcon">🖼️</div>
          <div>
            <div id="previewTitulo" style="font-size:24px;font-weight:700;margin-bottom:8px">Nenhum item selecionado</div>
            <div id="previewTexto" style="white-space:pre-wrap;line-height:1.5">Selecione ou crie um item.</div>
          </div>
        </div>
      </div>

      <div class="panel">
        <h3 style="margin-top:0">JSON gerado</h3>
        <div class="codeBox" id="jsonOut"></div>
      </div>
    </div>
  </div>
</div>

<script>
(() => {
  const api = {
    library: 'api/library_manifest.php',
    seed: 'api/seed_api.php',
    publish: 'api/publish_package.php'
  };
  const $ = id => document.getElementById(id);
  const state = {
    selectedCategoria:null, selectedItem:null, selectedAssetPath:null, mode:'categoria', assets:{},
    data:{ versao:1, idioma:'pt-PT', voz:{lang:'pt-PT', rate:1.0, pitch:1.0}, categorias:[], itens:[] }
  };

  function setStatus(m){ $('status').textContent=m; }
  function validId(id){ return /^[a-zA-Z0-9._-]+$/.test(id); }
  function esc(s){ return String(s).replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch])); }
  function syncMeta(){ state.data.versao=Number($('versao').value||1); state.data.idioma=$('idioma').value.trim()||'pt-PT'; state.data.voz.lang=$('vozLang').value.trim()||'pt-PT'; state.data.voz.rate=Number($('vozRate').value||1); state.data.voz.pitch=Number($('vozPitch').value||1); }
  function currentItemData(){ return {id:$('itemId').value.trim(), texto:$('itemTexto').value, categoria:$('itemCategoria').value, icone:$('itemIcone').value.trim()}; }
  function guessCat(path){ const p=String(path).split('/'); return p.length>=2 && p[0]==='icons' ? p[1] : ''; }
  function updateCatSelects(){
    const sels=[$('itemCategoria'), $('itemFilterCategoria'), $('assetFilterCategoria')];
    const vals=sels.map(s=>s.value);
    sels[0].innerHTML=''; sels[1].innerHTML='<option value="">Todas as categorias</option>'; sels[2].innerHTML='<option value="">Todas as categorias</option>';
    state.data.categorias.forEach(c=>{ const lbl=`${c.emoji||''} ${c.nome} (${c.id})`; sels.forEach(s=>{ const o=document.createElement('option'); o.value=c.id; o.textContent=lbl; s.appendChild(o);}); });
    vals.forEach((v,i)=>{ if(v===''||state.data.categorias.some(c=>c.id===v)) sels[i].value=v; });
  }
  function updateKPIs(){
    const used=new Set(state.data.itens.map(i=>i.icone).filter(Boolean));
    const missing=state.data.itens.filter(i=>i.icone && !state.assets[i.icone]).length;
    $('kpiCategorias').textContent=state.data.categorias.length; $('kpiItens').textContent=state.data.itens.length; $('kpiAssets').textContent=Object.keys(state.assets).length; $('kpiUsed').textContent=[...used].filter(p=>!!state.assets[p]).length; $('kpiMissing').textContent=missing;
  }
  function fillCategoriaForm(c){ $('catId').value=c.id||''; $('catNome').value=c.nome||''; $('catEmoji').value=c.emoji||''; }
  function fillItemForm(it){ $('itemId').value=it.id||''; $('itemTexto').value=it.texto||''; $('itemCategoria').value=it.categoria||''; $('itemIcone').value=it.icone||''; state.selectedAssetPath=state.assets[it.icone]?it.icone:null; $('selectedAssetPath').value=state.selectedAssetPath||''; renderPreview(); }
  function clearCategoria(){ $('catId').value=''; $('catNome').value=''; $('catEmoji').value=''; state.selectedCategoria=null; }
  function clearItem(){ $('itemId').value=''; $('itemTexto').value=''; $('itemIcone').value=''; if($('itemCategoria').options.length) $('itemCategoria').selectedIndex=0; state.selectedItem=null; state.selectedAssetPath=null; $('selectedAssetPath').value=''; renderPreview(); }
  function switchMode(mode){ state.mode=mode; $('categoriaForm').style.display=mode==='categoria'?'':'none'; $('itemForm').style.display=mode==='item'?'':'none'; $('tabCategoria').className='tabBtn'+(mode==='categoria'?' primary':''); $('tabItem').className='tabBtn'+(mode==='item'?' primary':''); }

  function renderCategorias(){
    const wrap=$('listaCategorias'); wrap.innerHTML='';
    if(!state.data.categorias.length){ wrap.innerHTML='<div class="mini">Sem categorias.</div>'; return; }
    state.data.categorias.forEach(c=>{ const count=state.data.itens.filter(i=>i.categoria===c.id).length; const el=document.createElement('div'); el.className='entry'+(state.selectedCategoria===c.id?' active':''); el.innerHTML=`<div class="entryTop"><div><div class="title">${esc(c.emoji)} ${esc(c.nome)}</div><div class="mini">${esc(c.id)} • ${count} item(ns)</div></div><button>Selecionar</button></div>`; el.querySelector('button').addEventListener('click',()=>{ state.selectedCategoria=c.id; fillCategoriaForm(c); switchMode('categoria'); renderAll(); setStatus('Categoria selecionada: '+c.id); }); wrap.appendChild(el); });
  }
  function renderItens(){
    const wrap=$('listaItens'); wrap.innerHTML=''; const term=$('itemSearch').value.trim().toLowerCase(); const cat=$('itemFilterCategoria').value; const miss=$('itemMissingIconFilter').value;
    const items=state.data.itens.filter(it=>{ const txt=[it.id,it.texto,it.categoria,it.icone].join(' ').toLowerCase(); const okTerm=!term||txt.includes(term); const okCat=!cat||it.categoria===cat; const has=!!state.assets[it.icone]; const okMiss=!miss||(miss==='missing'?!has:has); return okTerm&&okCat&&okMiss; });
    if(!items.length){ wrap.innerHTML='<div class="mini">Sem itens para mostrar.</div>'; return; }
    items.forEach(it=>{ const has=!!state.assets[it.icone]; const el=document.createElement('div'); el.className='entry'+(state.selectedItem===it.id?' active':''); el.innerHTML=`<div class="entryTop"><div><div class="title">${esc(it.texto)}</div><div class="mini">${esc(it.id)} • ${esc(it.categoria)} • ${has?'pictograma disponível':'ícone em falta'}</div><div class="mini">${esc(it.icone)}</div></div><button>Selecionar</button></div>`; el.querySelector('button').addEventListener('click',()=>{ state.selectedItem=it.id; fillItemForm(it); switchMode('item'); renderAll(); setStatus('Item selecionado: '+it.id); }); wrap.appendChild(el); });
  }
  function renderAssets(){
    const wrap=$('assetGrid'); wrap.innerHTML=''; const term=$('assetSearch').value.trim().toLowerCase(); const cat=$('assetFilterCategoria').value; const usage=$('assetUsageFilter').value; const usedSet=new Set(state.data.itens.map(i=>i.icone).filter(Boolean));
    const assets=Object.values(state.assets).filter(a=>{ const t=[a.name,a.path,a.category,...(a.tags||[])].join(' ').toLowerCase(); const okTerm=!term||t.includes(term); const okCat=!cat||a.category===cat; const used=usedSet.has(a.path); const okUsage=!usage||(usage==='used'?used:!used); return okTerm&&okCat&&okUsage; }).sort((a,b)=>a.path.localeCompare(b.path));
    if(!assets.length){ wrap.innerHTML='<div class="mini">Sem pictogramas para mostrar.</div>'; return; }
    assets.forEach(a=>{ const used=usedSet.has(a.path); const el=document.createElement('div'); el.className='assetCard'+(state.selectedAssetPath===a.path?' selected':''); el.innerHTML=`<div class="assetThumb">${a.content}</div><div class="assetName">${esc(a.name||a.fileName||a.path)}</div><div class="assetMeta">${esc(a.category||'sem categoria')}<br>${esc(a.path)}</div><div><span style="display:inline-block;padding:2px 8px;border-radius:999px;border:1px solid #334155;font-size:12px;color:#94a3b8">${used?'usado':'livre'}</span></div><div class="toolbar"><button data-a="select">Selecionar</button></div>`; el.querySelector('[data-a="select"]').addEventListener('click',()=>{ state.selectedAssetPath=a.path; $('selectedAssetPath').value=a.path; renderAssets(); setStatus('Pictograma selecionado: '+a.path); }); wrap.appendChild(el); });
  }
  function renderPreview(){ const it=state.data.itens.find(x=>x.id===state.selectedItem); const box=$('previewIcon'); if(!it){ box.innerHTML='🖼️'; $('previewTitulo').textContent='Nenhum item selecionado'; $('previewTexto').textContent='Selecione ou crie um item.'; return; } $('previewTitulo').textContent=it.texto||it.id; $('previewTexto').textContent='Categoria: '+it.categoria+'\\nÍcone: '+it.icone; if(state.assets[it.icone]) box.innerHTML=state.assets[it.icone].content; else box.textContent='🖼️'; }
  function renderJson(){ $('jsonOut').textContent=JSON.stringify(state.data,null,2); }
  function renderAll(){ syncMeta(); updateCatSelects(); updateKPIs(); renderCategorias(); renderItens(); renderAssets(); renderPreview(); renderJson(); }

  function saveCategoria(){ const c={id:$('catId').value.trim(), nome:$('catNome').value.trim(), emoji:$('catEmoji').value.trim()}; if(!c.id||!validId(c.id)||!c.nome||!c.emoji) return setStatus('Categoria inválida.'); const idx=state.data.categorias.findIndex(x=>x.id===c.id); if(idx>=0) state.data.categorias[idx]=c; else state.data.categorias.push(c); state.selectedCategoria=c.id; renderAll(); setStatus('Categoria guardada.'); }
  function saveItem(){ const it=currentItemData(); if(!it.id||!validId(it.id)||!it.texto.trim()||!it.categoria||!it.icone) return setStatus('Item inválido.'); const idx=state.data.itens.findIndex(x=>x.id===it.id); if(idx>=0) state.data.itens[idx]=it; else state.data.itens.push(it); state.selectedItem=it.id; renderAll(); setStatus('Item guardado.'); }
  function duplicateCategoria(){ const c=state.data.categorias.find(x=>x.id===state.selectedCategoria); if(!c) return; let base=c.id+'_copy', cand=base, n=2; while(state.data.categorias.some(x=>x.id===cand)) cand=base+'_'+(n++); const clone=JSON.parse(JSON.stringify(c)); clone.id=cand; clone.nome+=' (Cópia)'; state.data.categorias.push(clone); state.selectedCategoria=cand; fillCategoriaForm(clone); renderAll(); }
  function duplicateItem(){ const it=state.data.itens.find(x=>x.id===state.selectedItem); if(!it) return; let base=it.id+'_copy', cand=base, n=2; while(state.data.itens.some(x=>x.id===cand)) cand=base+'_'+(n++); const clone=JSON.parse(JSON.stringify(it)); clone.id=cand; clone.texto+=' (Cópia)'; state.data.itens.push(clone); state.selectedItem=cand; fillItemForm(clone); renderAll(); }
  function deleteCategoria(){ if(!state.selectedCategoria) return; if(state.data.itens.some(i=>i.categoria===state.selectedCategoria)) return setStatus('Categoria em uso por itens.'); state.data.categorias=state.data.categorias.filter(c=>c.id!==state.selectedCategoria); clearCategoria(); renderAll(); }
  function deleteItem(){ if(!state.selectedItem) return; state.data.itens=state.data.itens.filter(i=>i.id!==state.selectedItem); clearItem(); renderAll(); }
  function applyAssetToItem(){ if(!state.selectedAssetPath) return setStatus('Nenhum pictograma selecionado.'); $('itemIcone').value=state.selectedAssetPath; $('selectedAssetPath').value=state.selectedAssetPath; switchMode('item'); renderPreview(); renderJson(); setStatus('Pictograma aplicado ao item atual.'); }

  async function loadLibrary(){ try{ setStatus('A carregar biblioteca...'); const r=await fetch('api/library_manifest.php',{credentials:'include'}); if(!r.ok) throw new Error('HTTP '+r.status); const j=await r.json(); state.assets={}; (j.items||[]).forEach(a=>state.assets[a.path]=a); renderAll(); setStatus('Biblioteca carregada.'); }catch(e){ setStatus('Erro a carregar biblioteca.'); } }
  async function loadSeed(){ try{ setStatus('A carregar seed...'); const r=await fetch('api/seed_api.php',{credentials:'include'}); if(!r.ok) throw new Error('HTTP '+r.status); const j=await r.json(); state.data=j; $('versao').value=j.versao||1; $('idioma').value=j.idioma||'pt-PT'; $('vozLang').value=(j.voz&&j.voz.lang)||'pt-PT'; $('vozRate').value=(j.voz&&j.voz.rate)||1; $('vozPitch').value=(j.voz&&j.voz.pitch)||1; state.selectedCategoria=state.data.categorias[0]?.id||null; state.selectedItem=state.data.itens[0]?.id||null; if(state.selectedCategoria) fillCategoriaForm(state.data.categorias[0]); if(state.selectedItem) fillItemForm(state.data.itens[0]); renderAll(); setStatus('Seed carregado.'); }catch(e){ setStatus('Erro a carregar seed.'); } }
  async function publish(){ try{ syncMeta(); const used=[...new Set(state.data.itens.map(i=>i.icone).filter(Boolean))]; const assets=used.filter(p=>state.assets[p]).map(p=>({path:p,content:state.assets[p].content,fileName:state.assets[p].fileName||''})); const r=await fetch('api/publish_package.php',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify({seed:state.data,assets})}); const j=await r.json(); if(!j.ok) throw new Error(j.error||'erro'); setStatus('Publicado com sucesso.'); }catch(e){ setStatus('Erro a publicar.'); } }

  $('loadServerLibraryBtn').addEventListener('click',loadLibrary);
  $('loadServerSeedBtn').addEventListener('click',loadSeed);
  $('publishServerBtn').addEventListener('click',publish);
  $('tabCategoria').addEventListener('click',()=>switchMode('categoria'));
  $('tabItem').addEventListener('click',()=>switchMode('item'));
  $('saveCategoria').addEventListener('click',saveCategoria);
  $('clearCategoria').addEventListener('click',()=>{ clearCategoria(); renderAll(); });
  $('dupCategoria').addEventListener('click',duplicateCategoria);
  $('delCategoria').addEventListener('click',deleteCategoria);
  $('saveItem').addEventListener('click',saveItem);
  $('clearItem').addEventListener('click',()=>{ clearItem(); renderAll(); });
  $('dupItem').addEventListener('click',duplicateItem);
  $('delItem').addEventListener('click',deleteItem);
  $('applyAssetToItem').addEventListener('click',applyAssetToItem);
  $('itemSearch').addEventListener('input',renderItens);
  $('itemFilterCategoria').addEventListener('change',renderItens);
  $('itemMissingIconFilter').addEventListener('change',renderItens);
  $('assetSearch').addEventListener('input',renderAssets);
  $('assetFilterCategoria').addEventListener('change',renderAssets);
  $('assetUsageFilter').addEventListener('change',renderAssets);
  ['versao','idioma','vozLang','vozRate','vozPitch','itemTexto','itemIcone','itemCategoria'].forEach(id=>$(id).addEventListener('input',()=>{ syncMeta(); const temp=currentItemData(); $('previewTitulo').textContent=temp.texto||'Nenhum item selecionado'; $('previewTexto').textContent=temp.texto?('Categoria: '+temp.categoria+'\\nÍcone: '+temp.icone):'Selecione ou crie um item.'; if(state.assets[temp.icone]) $('previewIcon').innerHTML=state.assets[temp.icone].content; else $('previewIcon').textContent='🖼️'; renderJson(); updateKPIs(); }));
  renderAll();
})();
</script>
</body>
</html>
