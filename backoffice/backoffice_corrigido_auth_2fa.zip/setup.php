<?php
require __DIR__ . '/lib/bootstrap.php';
ensure_auth(); $u=current_user();
?><!doctype html>
<html lang="pt"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Setup 2FA</title>
<style>body{font-family:Arial;background:#0f172a;color:#e5e7eb;margin:0}.wrap{max-width:900px;margin:0 auto;padding:20px}.card{background:#111827;border:1px solid #334155;border-radius:16px;padding:18px}code,textarea{display:block;width:100%;background:#020617;color:#d1fae5;border:1px solid #334155;border-radius:10px;padding:12px;box-sizing:border-box}a{color:#93c5fd}</style>
</head><body><div class="wrap"><p><a href="dashboard.php">← Dashboard</a></p><div class="card"><h2>Setup 2FA</h2><p>Conta: <strong><?= h($u['username']) ?></strong></p><p><strong>Segredo Base32:</strong></p><code><?= h((string)$u['totp_secret']) ?></code><p>Adiciona este segredo manualmente na tua app autenticadora.</p></div></div></body></html>
